# Event-based Action Recognition Using Motion Information and Spiking Neural Networks

IJCAI2021
    
## Research Question:
   How to use Spiking Neural Network with motion information to deal with event-based action recognition task.
  
## Motivation:
  The events from the event-based camera are tirggered by dynamic changes, which makes it an ideal choice to capture actions in the visual scene.
  
