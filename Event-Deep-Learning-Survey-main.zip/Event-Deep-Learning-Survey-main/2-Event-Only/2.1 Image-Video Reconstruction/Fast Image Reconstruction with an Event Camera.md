# Fast Image Reconstruction with an Event Camera

WACV 2022

# Research Question

For image reconstruction, how to reduce the model size, memory footprint, FLOPs and power consumption and latency.

# Method

1) Only CNN network was utilized in the method.
2) All layers use single-strided (no downsampling).

# Weakness

Too Simple

